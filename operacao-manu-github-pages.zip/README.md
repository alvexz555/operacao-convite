# Operação Manu ❤️

Página romântica/interativa feita em HTML, CSS e JavaScript puro.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie `index.html`, `style.css` e `script.js` para a raiz do repositório.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde o GitHub Pages publicar.

## Personalização

O texto das respostas fica no `script.js`.
O visual principal fica no `style.css`.

Não há dependências externas, então a página funciona como um site estático comum.
